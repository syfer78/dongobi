package me.genomatch.http.config;

public class HttpConfig {
}
