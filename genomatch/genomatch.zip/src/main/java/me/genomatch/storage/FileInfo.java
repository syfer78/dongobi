package me.genomatch.storage;

public interface FileInfo {
    String getInfo(String key);
}
