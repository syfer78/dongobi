package me.genomatch.storage.sharefile.exception;

public class InitializeFailedException extends Exception {
    public InitializeFailedException(Exception e) {
        super(e);
    }
}
